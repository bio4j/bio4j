/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.era7.bioinfo.up.programs;

import com.era7.bioinfo.uniprotneo4jmodel.model.neo4j.nodes.GoTermNode;
import com.era7.bioinfo.uniprotneo4jmodel.model.neo4j.relationships.GoParentRel;
import com.era7.bioinfo.uniprotneo4jmodel.model.neo4j.relationships.go.BiologicalProcessRel;
import com.era7.bioinfo.uniprotneo4jmodel.model.neo4j.relationships.go.CellularComponentRel;
import com.era7.bioinfo.uniprotneo4jmodel.model.neo4j.relationships.go.MainGoRel;
import com.era7.bioinfo.uniprotneo4jmodel.model.neo4j.relationships.go.MolecularFunctionRel;
import com.era7.bioinfo.up.CommonData;
import com.era7.lib.era7xmlapi.model.XMLElement;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.jdom.Element;
import org.neo4j.index.lucene.LuceneIndexBatchInserter;
import org.neo4j.index.lucene.LuceneIndexBatchInserterImpl;
import org.neo4j.kernel.impl.batchinsert.BatchInserter;
import org.neo4j.kernel.impl.batchinsert.BatchInserterImpl;

/**
 *
 * @author ppareja
 */
public class ImportaOntologiaGo {

    public static final String PROPERTIES_FILE_NAME = "batchInserter.properties";

    public static final String TERM_TAG_NAME = "term";
    public static final String ID_TAG_NAME = "id";
    public static final String NAME_TAG_NAME = "name";
    public static final String DEF_TAG_NAME = "def";
    public static final String DEFSTR_TAG_NAME = "defstr";
    public static final String IS_A_TAG_NAME = "is_a";
    public static final String IS_ROOT_TAG_NAME = "is_root";
    public static final String NAMESPACE_TAG_NAME = "namespace";

    public static final String MOLECULAR_FUNCTION_GO_ID = "GO:0003674";
    public static final String BIOLOGICAL_PROCESS_GO_ID = "GO:0008150";
    public static final String CELLULAR_COMPONENT_GO_ID = "GO:0005575";

    public static void main(String[] args) {

        if (args.length != 1) {
            System.out.println("El programa espera un parametro: \n"
                    + "1. Nombre del archivo xml con la ontologia de go comleta \n");
        } else {
            File inFile = new File(args[0]);

            //boolean transactionDone = true;

            try {
                // create the batch inserter
                BatchInserter inserter = new BatchInserterImpl(CommonData.DATABASE_FOLDER, BatchInserterImpl.loadProperties(PROPERTIES_FILE_NAME));

                // create the batch index service
                LuceneIndexBatchInserter indexService = new LuceneIndexBatchInserterImpl(inserter);

                //------------------nodes properties maps-----------------------------------
                Map<String, Object> goProperties = new HashMap<String, Object>();
                //--------------------------------------------------------------------------

                //--------------------------------relationships------------------------------------------
                GoParentRel goParentRel = new GoParentRel(null);
                MainGoRel mainGoRel = new MainGoRel(null);
                CellularComponentRel cellularComponentRel = new CellularComponentRel(null);
                BiologicalProcessRel biologicalProcessRel = new BiologicalProcessRel(null);
                MolecularFunctionRel molecularFunctionRel = new MolecularFunctionRel(null);
                //--------------------------------------------------------------------------

                Map<String, ArrayList<String>> termParentsMap = new HashMap<String, ArrayList<String>>();

                int contador = 1;
                int limitForPrintingOut = 10000;

                BufferedReader reader = new BufferedReader(new FileReader(inFile));
                String line = null;
                StringBuilder termStBuilder = new StringBuilder();


                System.out.println("inserting nodes....");

                //-----first I create all the elements whitout their relationships-------------

                while ((line = reader.readLine()) != null) {
                    if (line.trim().startsWith("<" + TERM_TAG_NAME)) {

                        while (!line.trim().startsWith("</" + TERM_TAG_NAME + ">")) {
                            termStBuilder.append(line);
                            line = reader.readLine();
                        }
                        //linea final del organism
                        termStBuilder.append(line);
                        //System.out.println("organismStBuilder.toString() = " + organismStBuilder.toString());
                        XMLElement termXMLElement = new XMLElement(termStBuilder.toString());
                        termStBuilder.delete(0, termStBuilder.length());

                        String goId = termXMLElement.asJDomElement().getChildText(ID_TAG_NAME);
                        String goName = termXMLElement.asJDomElement().getChildText(NAME_TAG_NAME);
                        if(goName == null){
                            goName = "";
                        }
                        String goNamespace = termXMLElement.asJDomElement().getChildText(NAMESPACE_TAG_NAME);
                        if(goNamespace == null){
                            goNamespace = "";
                        }
                        String goDefinition = "";
                        Element defElem = termXMLElement.asJDomElement().getChild(DEF_TAG_NAME);
                        if(defElem != null){
                            Element defstrElem = defElem.getChild(DEFSTR_TAG_NAME);
                            if(defstrElem != null){
                                goDefinition = defstrElem.getText();
                            }
                        }

                        //----term parents----
                        List<Element> termParentTerms = termXMLElement.asJDomElement().getChildren(IS_A_TAG_NAME);
                        ArrayList<String> array = new ArrayList<String>();
                        for (Element elem : termParentTerms) {
                            array.add(elem.getText().trim());
                        }
                        //---------------------

                        goProperties.put(GoTermNode.ID_PROPERTY, goId);
                        goProperties.put(GoTermNode.NAME_PROPERTY, goName);
                        goProperties.put(GoTermNode.DEFINITION_PROPERTY, goDefinition);
                        goProperties.put(GoTermNode.NAMESPACE_PROPERTY, goNamespace);
                        long currentGoTermId = inserter.createNode(goProperties);
                        indexService.index(currentGoTermId, GoTermNode.GO_TERM_ID_INDEX, goId);

                        //----IS ROOT ? ----
                        Element isRootElem = termXMLElement.asJDomElement().getChild(IS_ROOT_TAG_NAME);
                        if(isRootElem != null){
                            String temp = isRootElem.getTextTrim();
                            if(temp.equals("1")){
                                inserter.createRelationship(inserter.getReferenceNode(), currentGoTermId, mainGoRel, null);
                                if(goId.equals(MOLECULAR_FUNCTION_GO_ID)){
                                    inserter.createRelationship(inserter.getReferenceNode(), currentGoTermId, molecularFunctionRel, null);
                                }else if(goId.equals(BIOLOGICAL_PROCESS_GO_ID)){
                                    inserter.createRelationship(inserter.getReferenceNode(), currentGoTermId, biologicalProcessRel, null);
                                }else if(goId.equals(CELLULAR_COMPONENT_GO_ID)){
                                    inserter.createRelationship(inserter.getReferenceNode(), currentGoTermId, cellularComponentRel, null);
                                }
                                
                            }
                        }
                        //----------------------                        

                    }
                    contador++;
                    if ((contador % limitForPrintingOut) == 0) {
                        System.out.println(contador + " terms inserted!!");
                    }
                }
                reader.close();

                //-----------------------------------------------------------------------

                System.out.println("Inserting relationships....");

                //-------------------now I create the relationships-----------------
                Set<String> keys = termParentsMap.keySet();
                for (String key : keys) {
                    long currentNodeId = indexService.getSingleNode(GoTermNode.GO_TERM_ID_INDEX, key);
                    ArrayList<String> tempArray = termParentsMap.get(key);
                    for (String string : tempArray) {
                        long tempNodeId = indexService.getSingleNode(GoTermNode.GO_TERM_ID_INDEX, string);
                        inserter.createRelationship(currentNodeId, tempNodeId, goParentRel, null);
                    }
                }
                //------------------------------------------------------------------

                System.out.println("Done! :)");

                System.out.println("Closing up inserter and index service....");
                // shutdown, makes sure all changes are written to disk
                inserter.shutdown();
                indexService.shutdown();
                


            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
